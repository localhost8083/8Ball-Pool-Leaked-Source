<a href="index.php">Home</a>
<a href="inv.php">Invites</a>
<a href="sub.php">Subs</a>