<?php

$version       = "2.0";
$gUserAgent    = "Easy-Victory Private Key";
const SECURITY = 1; // dummy var to prevent the funny